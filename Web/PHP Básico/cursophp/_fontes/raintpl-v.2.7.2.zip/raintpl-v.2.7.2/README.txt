  RainTPL
-------------

The easy and fast template engine for PHP.   Rain.TPL makes application easier to create & enables designers/developers to work better together.